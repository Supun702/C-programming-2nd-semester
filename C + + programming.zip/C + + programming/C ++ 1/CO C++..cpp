#include <iostream>
using namespace std;

int main()
{ 
  int InputVoltage, n;
  float LEDVoltagedrop, CurrentThroughLED, ResistorVoltagedrop, Resistorvalue;
  InputVoltage= 5.5;
  LEDVoltagedrop= 2.2;
  cout<<"Enter the number of LED ";
  cin>>n;
  cout<<"Enter the CurrentThroughLED ";
  cin>>CurrentThroughLED;
  ResistorVoltagedrop = (InputVoltage- (n*LEDVoltagedrop));
  Resistorvalue =(ResistorVoltagedrop/CurrentThroughLED ); 
  cout<<"The resistor value is "<<Resistorvalue; 
  return 0; 
}
