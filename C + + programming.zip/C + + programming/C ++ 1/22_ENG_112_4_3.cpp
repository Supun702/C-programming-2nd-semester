#include <iostream>
using namespace std;

int recursiveFibonacci(int n) 
{
    if (n<=1) 
	{
        return n;
    } 
	else 
	{
        return recursiveFibonacci(n - 1) + recursiveFibonacci(n - 2);
    }
}

int main() 
{
    int n;
    cout<<"Enter the value of n: ";
    cin>>n;

    if(n<0) 
	{
        cout <<"Invalid input. Please enter a positive integer."<<endl;
        return 1; // Exit with an error code
    }
    else
    {	
        cout <<"The "<<n<<"th number in the Fibonacci series is: "<<recursiveFibonacci(n)<<endl;
    }
    
    return 0;
}
