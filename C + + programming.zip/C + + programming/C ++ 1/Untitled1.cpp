#include <iostream>
using namespace std;

int main()
{
	int marks;
    string userinput;
    int units;
    cout<<"enter the userinput: ";
    cin>>userinput;
    cout<<"enter the units: ";
    cin>>units;
    
    
  if(userinput == "Domestic" )
    if(units <= 50)
    {
    	cout<<"a";
	}
	else if(units <= 100)
	{
		cout<<"b";
	}
	else if(units <= 150)
	{
		cout<<"c";
	}
	
    else if(userinput == "Business" && units <= 50)
	{
    	cout<<"e";
	}
	else if(units <= 100)
	{
		cout<<"f";
	}
	else
	{
		cout<<"g";
	}
}
