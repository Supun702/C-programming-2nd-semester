#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	double number1, number2, result;
	char operation;
	bool exitprograme = false; 
	
	while(!exitprograme)
	{
		// Input two numbers to calculate methamatical works....
		cout<<"Enter first number: ";
		cin>> number1;
		
		cout<<"Enter second number: ";
		cin>> number2;
		
		// Accept the operation user need to do....
		cout<<"Enter operation\n\nA or a for addition\nS or s for subtraction\nM or m for multiplication\nD or d for division\nR or r for remainder\nP or p for power\nX or x for exit\n\n";
		cin>> operation; 
		
		switch(operation)
		{
			case 'A':
			case 'a':
				result = number1+number2;
				break;
			
			case 'S':
			case 's':
				result = number1-number2;
				break;
			
			case 'M':
			case 'm':
				result = number1*number2;
				break;
			
			case 'D':
			case 'd':
				if (number2 !=0)
				{
					result = number1/number2;
				}
				else
				{
					cout<<"Error: Division by 0 is not supported.\n";
					continue; // skip to next....
				}
			    break;
			
			case 'R':
			case 'r':
				result = fmod(number1,number2);
				break;
			
			case 'P':
			case 'p':
				result = pow(number1,number2);
				break;
			
			case 'X':
			case 'x':
				exitprograme = true;
				break;
			default:
				cout<< "Error: Invalid operation\n\n";
				continue; // skip to next.....			
			
		}
		
		// Display the result....
		cout<< "Result: "<< result << endl << endl;	
	}
	
	return 0;
	
}
