#include <iostream>
using namespace std;

int main()
{
   int year1,year2,year3,year4;
   int month1,month2,month3,month4,month5;
   int day1, day2, day3;
   int sum;
   int luckyNumber;

   cout<<"enter the year of birth: "<<endl;
   cin>>year1; 
   cin>>year2;
   cin>>year3;
   cin>>year4;
   
   cout<<"enter the month of birth: "<<endl;
   cin>>month1;
   cin>>month2;
   
   cout<<"enter the day of birth: "<<endl;
   cin>>day1;
   cin>>day2;
   
   sum = (year1+year2+year3+year4 + month1+month2 + day1+day2);
   
   if(sum <9)
   { 
     cout<<"the lucky number is: "<< sum<<endl;
   
   }
}
