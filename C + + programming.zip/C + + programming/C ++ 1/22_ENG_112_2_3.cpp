#include <iostream>
using namespace std;

int main() 
{
    int marks;
    cout << "Enter the marks: ";
    cin >> marks;

    if (marks >= 0 && marks <= 100) {
        if (marks > 74) {
            cout << "A" << endl;
        } else if (marks > 59) {
            cout << "B" << endl;
        } else if (marks > 44) {
            cout << "C" << endl;
        } else if (marks > 34) {
            cout << "D" << endl;
        } else {
            cout << "F" << endl;
        }
    } else {
        cout << "Error: marks should be between 0 and 100" << endl;
    }

    return 0;
}
