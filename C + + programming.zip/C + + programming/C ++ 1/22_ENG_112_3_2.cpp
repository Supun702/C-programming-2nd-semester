#include <iostream>
using namespace std;

enum months
{
	JAN = 1,
	FEB,
	MAR,
	APR,
	MAY,
	JUN,
	JUL,
	AUG,
	SEP,
	OCT,
	NOV,
	DEC
};

int main()	
{
	int usermonth;
	
	cout<< "Enter your number of month of birth: ";
	cin>> usermonth;
  
	switch(usermonth)
	{
		case JAN:
			cout<< "January" << endl;
			break;
		
		case FEB:
			cout<< "February" << endl;
			break;
		
		case MAR:
			cout<< "March" << endl;
			break;
		
		case APR:
			cout<< "April" << endl;
			break;
			
		case MAY:
			cout<< "May" << endl;
			break;
		
		case JUN:
			cout<< "June" << endl;
			break;
		
		case JUL:
			cout<< "July" << endl;
			break;
		
		case AUG:
			cout<< "August" << endl;
			break;
		
		case SEP:
			cout<< "September" << endl;
			break;
		
		case OCT:
			cout<< "October" << endl;
			break;
		
		case NOV:
			cout<< "November" << endl;
			break;
		
		case DEC:
			cout<< "December" << endl;
			break;
		
		default:
			cout<< "Invalid month number" << endl;
			break;
			
	}	
	return 0;
}
