#include <iostream>
#include <cstring>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <state abbreviation>\n";
        return 1;
    }

    char* abbreviation = argv[1];

    // Convert the abbreviation to uppercase
    for (int i = 0; i < 2; ++i) {
        abbreviation[i] = std::toupper(abbreviation[i]);
    }

    // Switch-case statements for state abbreviations
    switch (abbreviation[0]) {
        case 'A':
            switch (abbreviation[1]) {
                case 'K':
                    std::cout << "Alaska\n";
                    break;
                case 'L':
                    std::cout << "Alabama\n";
                    break;
                // Add more cases as needed
                default:
                    std::cerr << "Invalid state abbreviation\n";
                    return 1;
            }
            break;
        case 'C':
            switch (abbreviation[1]) {
                case 'A':
                    std::cout << "California\n";
                    break;
                case 'O':
                    std::cout << "Colorado\n";
                    break;
                // Add more cases as needed
                default:
                    std::cerr << "Invalid state abbreviation\n";
                    return 1;
            }
            break;
        // Add more cases as needed for other states
        default:
            std::cerr << "Invalid state abbreviation\n";
            return 1;
    }

    return 0;
}
