#include <iostream>
using namespace std;

int main()
{
	char userInput1, userInput2;
	bool exitprograme = false;
	
	cout<<"If you need to exit this programme, you will select the x letter to 1st and 2nd\n\n";
	 
  while(!exitprograme)
  {
	cout<<"Enter your 1st letter: ";
	cin>> userInput1;
	
	cout<<"Enter your 2nd letter: ";
	cin>> userInput2;
	
	switch(userInput1)
	{
		case 'A':
		case 'a':
			switch(userInput2)
			{
				case 'L':
				case 'l':
				cout<< "\nAlabama" << endl;
				break;
				
				case 'K':
				case 'k':
				cout<< "\nAlaska" << endl;
				break;
				
				case 'Z':
				case 'z':
				cout<< "\nArizona" << endl;
				break;
				
				case 'R':
				case 'r':
				cout<< "\nArkansas" << endl;
				break;
			
				case 'S':
				case 's':
				cout<< "\nAmerican Samoa" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				
			}
			
		break;
			
	   	case 'C':
		case 'c':
			switch(userInput2)
			{
				case 'A':
				case 'a':
				cout<< "\nCalifornia" << endl;
				break;
			
				case 'O':
				case 'o':
				cout<< "\nColorado" << endl;
				break;
			
				case 'T':
				case 't':
				cout<< "\nConnecticut" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
			}
			
		break;
		
		case 'D':
		case 'd':
			switch(userInput2)
			{
				case 'E':
				case 'e':
				cout<< "\nDelaware" << endl;
				break;
				
				case 'C':
				case 'c':
				cout<< "\nDistrict of Columbia" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
			}
		
		break;
		
		case 'F':
		case 'f':
			switch(userInput2)
			{
				case 'L':
				case 'l':
				cout<< "\nFlorida" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'G':
		case 'g':
			switch(userInput2)
			{
				case 'A':
				case 'a':
				cout<< "\nGeorgia" << endl;
				break;
				
				case 'U':
				case 'u':
				cout<< "\nGuam" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
			}
		
		break;
		
		case 'H':
		case 'h':
			switch(userInput2)
			{
				case 'I':
				case 'i':
				cout<< "\nHawaii" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'I':
		case 'i':
			switch(userInput2)
			{
				case 'D':
				case 'd':
				cout<< "\nIdaho" << endl;
				break;
		
				case 'L':
				case 'l':
				cout<< "\nIllinois" << endl;
				break;
		
				case 'N':
				case 'n':
				cout<< "\nIndiana" << endl;
				break;
			
				case 'A':
				case 'a':
				cout<< "\nIowa" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
		    }
		    
		break;
		
		case 'K':
		case 'k':
			switch(userInput2)
			{
				case 'S':
				case 's':
				cout<< "\nKansas" << endl;
				break;
				
				case 'Y':
				case 'y':
				cout<< "\nKentucky" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
			}
		
		break;
		
		case 'L':
		case 'l':
			switch(userInput2)
			{
				case 'A':
				case 'a':
				cout<< "\nLouisiana" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'M':
		case 'm':
			switch(userInput2)
			{
				case 'E':
				case 'e':
				cout<< "\nMaine" << endl;
				break;
		
				case 'D':
				case 'd':
				cout<< "\nMaryland" << endl;
				break;
		
				case 'A':
				case 'a':
				cout<< "\nMassachusetts" << endl;
				break;
				
				case 'I':
				case 'i':
				cout<< "\nMichigan" << endl;
				break;
		
				case 'N':
				case 'n':
				cout<< "\nMinnesota" << endl;
				break;
		
				case 'S':
				case 's':
				cout<< "\nMississippi" << endl;
				break;
			
				case 'O':
				case 'o':
				cout<< "\nMissouri" << endl;
				break;
			
				case 'T':
				case 't':
				cout<< "\nMontana" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
			}
		
		break;
		
		case 'N':
		case 'n':
			switch(userInput2)
			{
				case 'E':
				case 'e':
				cout<< "\nNebraska" << endl;
				break;
		
				case 'V':
				case 'v':
				cout<< "\nNevada" << endl;
				break;
		
				case 'H':
				case 'h':
				cout<< "\nNew Hampshire" << endl;
				break;
				
				case 'J':
				case 'j':
				cout<< "\nNew Jersey" << endl;
				break;
		
				case 'M':
				case 'm':
				cout<< "\nNew Mexico" << endl;
				break;
		
				case 'Y':
				case 'y':
				cout<< "\nNew York" << endl;
				break;
			
				case 'C':
				case 'c':
				cout<< "\nNorth Carolina" << endl;
				break;
			
				case 'D':
				case 'd':
				cout<< "\nNorth Dakota" << endl;
				break;
				
				case 'P':
				case 'p':
				cout<< "\nNorthern Mariana Islands" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
			}
		
		break;
		
		case 'O':
		case 'o':
			switch(userInput2)
			{
				case 'H':
				case 'h':
				cout<< "\nOhio" << endl;
				break;
		
				case 'K':
				case 'k':
				cout<< "\nOklahoma" << endl;
				break;
		
				case 'R':
				case 'r':
				cout<< "\nOregon" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'P':
		case 'p':
			switch(userInput2)
			{
				case 'A':
				case 'a':
				cout<< "\nPennsylvania" << endl;
				break;
		
				case 'R':
				case 'r':
				cout<< "\nPuerto Rico" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'R':
		case 'r':
			switch(userInput2)
			{
				case 'I':
				case 'i':
				cout<< "\nRhode Island" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'S':
		case 's':
			switch(userInput2)
			{
				case 'C':
				case 'c':
				cout<< "\nSouth Carolina" << endl;
				break;
		
				case 'D':
				case 'd':
				cout<< "\nSouth Dakota" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'T':
		case 't':
			switch(userInput2)
			{
				case 'N':
				case 'n':
				cout<< "\nTennessee" << endl;
				break;
		
				case 'X':
				case 'x':
				cout<< "\nTexas" << endl;
				break;
		
				case 'T':
				case 't':
				cout<< "\nTrust Territories" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'U':
		case 'u':
			switch(userInput2)
			{
				case 'T':
				case 't':
				cout<< "\nUtah" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'V':
		case 'v':
			switch(userInput2)
			{
				case 'T':
				case 't':
				cout<< "\nVermont" << endl;
				break;
		
				case 'A':
				case 'a':
				cout<< "\nVirginia" << endl;
				break;
		
				case 'I':
				case 'i':
				cout<< "\nVirgin Islands" << endl;
				break;
				default:
					cout<<"\nThere is no any territorial name that can be found in USA\n\n";
				return 1;
	    	}
	    
	    break;
	    
	    case 'W':
		case 'w':
			switch(userInput2)
			{
				case 'A':
				case 'a':
				cout<< "\nWashington" << endl;
				break;
		
				case 'V':
				case 'v':
				cout<< "\nWest Virginia" << endl;
				break;
		
				case 'I':
				case 'i':
				cout<< "\nWisconsin" << endl;
				break;
				
				case 'Y':
				case 'y':
				cout<< "\nWyoming" << endl;
				break;
				default:
			     	cout<<"\nThere is no any territorial name that can be found in USA\n\n";
			    return 1;
	    	}
	    	
	    break;
		   		
		case 'X':
		case 'x':
			switch(userInput2)
			{
				case 'X':
				case 'x':    
				exitprograme = true;
				cout<<"\nThe programme is gone to exit\n\n";
				break;									
			}
			
		break;
			
    	default:
	        cout<<"\nThere is no any territorial name that can be found in USA\n\n";
	        continue; // skip to next.....			
	    return 1;	
    }

  }
  return 0;
}

