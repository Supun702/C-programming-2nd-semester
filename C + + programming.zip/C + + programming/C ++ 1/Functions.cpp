#include <iostream>
#include <cmath>
using namespace std;


void printTraingle(int n)
    {
    	for(int row=1; row<=n; row++)
    	{
    		for(int col=1; col<=row; ++col)
    		{
    			cout<<"+";
			}
			cout<<endl;
		}
	}
	
int calculatePower(int number, int power)
{
	int answer=1;
	for(int a=1; a<=power; ++a)
	
		answer = answer*number;
	
	return answer;
}


bool validNumber(int number)
 {
 	int answer=1;
 	answer = (number>=1 && number<=100);
 	
 	return answer;
 }
	

void generateMonth (int number)
{
	switch(number)
	{
		case 1:
			cout<<"January";
			break;
		case 2:
			cout<<"February";
			break;
		case 3:
			cout<<"March";
			break;
		case 4:
			cout<<"Aprial";
			break;
		case 5:
			cout<<"May";
			break;
		case 6:
			cout<<"June";
			break;
		case 7:
			cout<<"July";
			break;
		case 8:
			cout<<"August";
			break;
		case 9:
			cout<<"September";
			break;
		case 10:
			cout<<"October";
			break;
		case 11:
			cout<<"November";
			break;
		case 12:
			cout<<"December";
			break;
		default:
		    cout<<"Please enter a valid number"<<endl;
		    break;
	}
}


double calculateFixedReturn(double loan, double annualInterestRate, int years)
{
	double monthlyLoan = loan/(12*years);
	double monthlyInterestRate = annualInterestRate/100/12;
	
	double monthlyPayment = monthlyLoan*100/monthlyInterestRate;
	double totalReturn = 12*years*(monthlyPayment - monthlyLoan);
	
	return totalReturn; 
	
}

int AddNumbers(int a,int b, int c)
{
	return a+b+c;
}

//fibonacci series -------------------------------------------------------------------------

int fibonacci(int i)
{
	if(i<=1)
	   return i;
	else
	   return fibonacci(i-1) + fibonacci(i-2);
}

void generateFibonacci(int n)
{
	cout<<"Fibonacci series"<<endl;
	for(int i=1; i<=n; ++i)
	{
		cout<<fibonacci(i)<<" ";
	}
}

//generate nCr ......

int factorialOfn (int n)
{
	if(n<=1)
	{
		return 1;
	}
	else
	{
		return n*factorialOfn(n-1);
	}
}

int factorialOfr (int r)
{
	if(r<=1)
	{
		return 1;
	}
	else
	{
		return r*factorialOfr(r-1);
	}
}

int factorialOfC (int c)
{
	if(c<=1)
	{
		return 1;
	}
	else
	{
		return (c)*factorialOfC(c-1);
	}	
}   
    

	
int main()
{
	/*int n;
	cout<<"Enter the lines: ";
	cin>>n;
	
	printTraingle(n);*/
	
	//*********************************************************
	
	/*int power,number;
	cout<<"Please input power: ";
	cin>>power;
	cout<<"Please input number: ";
	cin>>number;
	
	int answer= calculatePower(number,power);
	cout<<number<<"^"<<power<<"="<<answer<<endl;*/
	
	//---------------------------------------------------------------------------------------------------
	
	/*int number;
	cout<<"Please enter the number: ";
	cin>> number;
	
	if(validNumber(number))
	{
		cout<<"Valid number"<<endl;
	}
	else
	{
		cout<<"Invalid number.Please enter the correct number."<<endl;
	}*/
	
	//----------------------------------------------------------------------------------------------------
	
	/*int number;
	cout<<"Please enter the number: ";
	cin>>number;
	
	generateMonth(number);*/
	
	/*double loan, annualInterestRate;
	int years;
	
	cout<<"Enter the loan amount: ";
	cin>>loan;
	
	cout<<"Enter the annualInterestRate: ";
	cin>>annualInterestRate;
	
	cout<<"Enter the number of years: ";
	cin>>years;
	
	cout<<"Total return is: ";
	calculateFixedReturn(loan, annualInterestRate, years);*/
	
	//---------------------------------------------------------------------------------------
	
	/*cout<<"The sum of numbers is: "<<AddNumbers(2,4,6)<<endl;
	cout<<"The sum of numbers is: "<<AddNumbers(5,4,1)<<endl;
	cout<<"The sum of numbers is: "<<AddNumbers(1,1,1)<<endl;*/

	//---------------------------------------------------------------------------------------
	
	int n;
    cout<<"enter the value: ";       //fibonacci series...
    cin>>n;
    
    generateFibonacci(n);
    
    //---------------------------------------------------------------------------------------
    
    /*int n,r,c;
    cout<<"Display the nCr value for given inputs"<<endl;
    cout<<"n value: ";
    cin>>n;
    cout<<"r value: ";
    cin>>r;                          //nCr value
    cout<<"n-r value: ";
    cin>>c;
    
    cout<<"nCr"<<" "<<"="<<" "<<"n!"<<"/"<<"r!(n-r)!"<<" "<<"="<<" "<<factorialOfn(n)/(factorialOfr(r)*factorialOfC(c));*/
    

    return 0;
}
	
	

