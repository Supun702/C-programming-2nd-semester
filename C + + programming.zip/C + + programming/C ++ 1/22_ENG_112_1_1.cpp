#include <iostream>
#include <string>
using namespace std;

int calculateLuckyNumber(int year, int month, int day) {
    int sum = year + month + day;
    
    while (sum > 9) {
        int temp1 = sum;
        sum = 0;
        while (temp1 > 0) {
            sum += temp1 % 10;
            temp1 /= 10;
        }
    }
    return sum;
}

int main() {
	
    int year, month, day;
    int LuckyNumber;
    cout<< "Enter your year of birth: ";
    cin>> year;
    
    cout<< "Enter your month of birth: ";
    cin>> month;
    
    cout<< "Enter your day of birth: ";
    cin>> day;

    LuckyNumber = calculateLuckyNumber(year, month, day);
    cout<< "Your lucky number is: " << LuckyNumber << endl;

    return 0;
}














































