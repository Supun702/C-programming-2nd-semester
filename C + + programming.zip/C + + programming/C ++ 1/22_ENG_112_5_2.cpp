#include <iostream>
#include <cstring>
using namespace std; 

bool ValidDomain(char*domain)
{
	
	if(strcmp(domain, "com") == 0 && strcmp(domain, "org") == 0 && strcmp(domain, "gov") == 0 && strcmp(domain, "edu") == 0 && strcmp(domain, "lk") == 0)
	{
		return false;
	}
	else
	{
    	return true;
    }
}

bool EmailValidator(char*email)
{
	//Check if email address starts with alphabetical character....
	if(!isalpha(email[0]))
	{
		return false;
	}
	
	int atSymbolCount = 0;
	int DotCount = 0;
	
	for(int a = 0; a<strlen(email); a++)
	{
		//Check the space....
		if(isspace(email[a]))
		{
			return false;
		}
		
		//Check the @ symbol....
		if(email[a] == '@')
		{
			atSymbolCount ++;
			//Check if only one @ symbol in an email....
			if(atSymbolCount > 1)
			{
				return false;
			}
		}
		
		//Check for dot in the user name part of an email....
		if(email[a] == '.')
		{
			DotCount ++;
			//Check if only one dot in the user name part of an email....
			if(DotCount > 1)
			{
				return false;
			}
		}
	}
	
	//Check the domain part of an email....
    char*domain = strchr(email, '@');
    if(domain)
    {
        domain ++; //Move to the character after @....
    	if(!ValidDomain(domain))
    	{
	    	return false;
    	}
    }

    else
    {
    	//No @ symbol found....
 	    return false;
    }

    //If all conditions are satisfied....
    return true;	
}

int main()
{
	char email[128]; //128 characters
	cout<<"Enter the email address: ";
	cin>>email;
	
	if(EmailValidator(email))
	{
		cout<<"Valid email address......"<<endl;
	}
	else
	{
		cout<<"Invalid email address......"<<endl;
	}
	
	return 0;
}









