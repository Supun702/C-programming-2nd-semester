#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;


	float calculateMean (const float arr[], int size)
	{
		float sum =0;
		for(int i=0; i<size; i++)
		{
			sum += arr[i];
		}
		return sum/size;
	}
	
	float calculateVariance (const float arr[], int size)
	{
		float mean = calculateMean(arr, size);
		float variance =0;
		
		for(int i=0; i<size; i++)
		{
			variance += pow(arr[i]-mean,2);
		}
		return variance/(size-1);
	}
	
	void function(int array[])
	{
		for(int i=0; i<5; i++)
		{
			cout<<"element"<<i+1<<": "<<array[i]<<endl;
		}
	}
	
	void modifyArray(int array[])
	{
		for(int i=0; i<5; i++)
		{	
		    array[i] += 10;
		    cout<<"element"<<i+1<<": "<<array[i]<<endl;
	    }
	}
	
	
	
int main()
{		  
	/*typedef int supun;
	supun a = 2;
	
	cout<<"print: "<<a; */
	
	//-------------------------------------------------------------------------------------------
	
	/*
	int a=2, b=8;
	cout<< (a<b ? "true" : "false");*/
	
	/*int array[3] = {33,54,9};
    int*pointer = array;
    
    cout<<"array: "<<array<<endl;
    cout<<"&array: "<<&array<<endl;
    
    
    for(int i=0; i<3; i++)
    {
    	cout<<pointer + i<<"\t";
	}*/
	
	/*char letterOne, letterTwo;
	cout<<"please enter the letterOne and letterTwo: ";
	cin>> letterOne>> letterTwo;
	
	switch(letterOne)
	{
		case 'B':
			switch(letterTwo)
			{
				case 'I':
					cout<<"Biomedical engineering";
					break;
			}
		case 'C':
			switch(letterTwo)
			{
				case 'E':
					cout<<"Chemical engineering";
					break;
			}

	}*/
	
	/*char letter1,letter2;
	cout<<"please enter the letters: ";
	cin >> letter1>> letter2;
	int n;
	
	switch(letter1)
	{
		case 'a':
		case 'A':
			n = 26;
			break;
	}
	
	for(int i=0; i<n; i++)
	{
		cout<<letter1;
	}
	cout<<endl;
	
	switch(letter2)
	{
		case 'p':
		case 'P':
			n=1;
			break;
	}
	
	for(int j=0; j<n; j++)
	{
		cout<<letter2;
	}
	cout<<endl;*/
	
	//-------------------------------------------------------------------------------
	
    /*int n; 
    
    cout<<"Enter the number of elements: ";
    cin>> n;
    
    float arr[n];
    cout<<"Enter the elements of the array: "<<endl;
    
    for(int i=0; i<n; i++)
    {
    	cout<<"Element"<<i+1<<":";
    	cin>> arr[i];
	}
	
	cout<<"Variance of the element in the array: "<<calculateVariance(arr,n);*/
	
	//----------------------------------------------------------------------------------------
	
    /*char hexNumber[] = "7AF12";
    int decimalNumber = stoi(hexNumber, 0, 16);
    
    cout<<"hexnumber: "<<hexNumber<<endl;
    cout<<"decimalnumber: "<<decimalNumber<<endl;
    
    string octalNumber;
    while(decimalNumber>0)
    {
    	char digit = '0' + decimalNumber%8;
    	octalNumber = digit + octalNumber;
    	decimalNumber /= 8;
	}
	
	cout<<"hexnumber: "<<hexNumber<<endl;
    cout<<"octalnumber: "<<octalNumber<<endl;*/
    
    //--------------------------------------------------------------------------------------------------
    
	/*// Character array holding the original sentence
    char quotes[128] = "Great Minds Discuss Ideas, while Small Minds Discuss People.";
    cout<< quotes[100]<<endl;
    char newQuote[128];

    // Finding the length of the sentence
    int length = strlen(quotes);
    cout<< length<<endl;

    // Character array to store the modified sentence
    for (int j =0; j<length; j++)
    {
    	newQuote[j] = quotes[j];
	}
    
    // Swapping letters in each word
    for (int i = 0; i < length; ++i) {
        if (newQuote[i] != ' ' && newQuote[i] != ',' && newQuote[i] != '.') {
            int start = i;
            while (i < length && newQuote[i] != ' ' && newQuote[i] != ',' && newQuote[i] != '.') {
                ++i;
            }
            int end = i - 1;

            // Swap letters in the word
            while (start < end) {
                char temp = newQuote[start];
                newQuote[start] = newQuote[end];
                newQuote[end] = temp;
                ++start;
                --end;
            }
        }
    }

    // Output the result
    std::cout << "Original Sentence: " << quotes << std::endl;
    std::cout << "Modified Sentence: " << newQuote << std::endl;*/



   	/*const int row=3;
   	int array[row] = {2,3,4};
   	int *pointer = &array[0];
		
	for(int i=0; i<row; i++)
	{
		cout<<"element "<<i+1<<": "<<array[1]<<"\t"<<"address "<<i+1<<": "<<&array[i]<<endl;
		cout<<pointer + i<<endl;
	}*/
	
	
	
	/*const int row = 3;
	int total[2][row] = {{1,2,3},{4,5,6}};
	int *pointer = &total[0][0];
	
	for(int i=0; i<6; i++)
	{
		cout<< pointer + i<<"\t"<< &total[0][i]<<"\t"<< total[0][i]<<endl;
	}*/
	
	//-----------------------------------------------------------------------------------------------
	
	/*int quantity[5] = {2,3,4,5,6};
	function(quantity);
	
	cout<<sizeof(quantity)<<endl;
	
	modifyArray(quantity);*/
	
	
	// bubble sort ascending order....................................................................
	
	/*int n;
	
	cout<<"please enter the number of element that you like to enter: ";
	cin >> n;
	
	int array[n];
	cout<<"please input elements in array: ";
	
	for(int i=0; i<n; i++)
	{
		cin>> array[i];
	}
	
	char set =0;
	
	for(int j=0; j<n-1; j++)
	{
	   for(int i=0; i<n-1; i++)
	   {
		   if(array[i]<array[i+1])
	    	{
		    	array[i];
	    	}
	    	else
	    	{
		    	char set = array[i];
		    	array[i] = array[i+1];
			    array[i+1] = set;
		    }
	   }
    }
	
	for(int i=0; i<5; i++)
	{
		cout<< array[i]<<",";
	}*/
	
	
	
	/*char a= 'A';
	cout<<(int)a<<endl;	
	
	float c=10.145;
	int b = static_cast<int> (c);
	
	cout<<b;*/
	
	//----------------------------------------------------------------------------------
	
	/*const int row = 2, col = 3;
	int values[row][col] = {{2,3,4},{-4,5,9}};
	int*pointer[row][col];
	
	for(int i=0; i<row; i++)
	{
		for(int j=0; j<col; j++)
		{
			pointer[i][j] = &values[i][j];
			cout<<"address: "<<pointer[i][j]<<endl;
		}
	}*/
	
	
	/*int count = 215;
	int *firstPointer = &count;
	int **secondPointer = &firstPointer;
	
	*firstPointer -=21;
	**secondPointer++;
	*firstPointer /=15;
	cout<< count<<endl;*/
	
	
	
	
	
	return 0;
		
}
