#include <iostream>
#include <cmath>
#define pi 3.14
using namespace std;

int increase (int*value)
{
	cout<<"value: ="<<value<<endl;
	cout<<"*value: ="<<*value<<endl;
	
	return *value+=1;
	
}

float commonCircleArea (float x1, float x2, float y1, float y2, float r1, float r2)
{
	float d = sqrt(pow(x2-x1,2) + pow(y2-y1,2));
	float commonArea, a;
	
	if(d> r1+r2)
	{
	    
		float area1 = pi*pow(r1,2);
		float area2 = pi*pow(r2,2);
		
		if(area1>area2)
		{
			a = area1-area2;
		}
		else
		{
		    a = area2-area1;
		}
	}
	else
	{
		cout<<"circles are not intersecting."<<endl;
	}
	
	commonArea = a;
	return commonArea;
}

int main()
{
	/*int noOfStudents = 120;
	
	cout<<"value: "<<noOfStudents<<endl;
	cout<<"address: "<<&noOfStudents<<endl<<endl;
	
	int*pntvariable = &noOfStudents;
	cout<<"value: "<<noOfStudents<<endl;
	cout<<"value of stored address: "<<*pntvariable<<endl;
	cout<<"adress of pointer variable: "<<&pntvariable<<endl;
	cout<<"stored address: "<<pntvariable<<endl<<endl;
	
	*pntvariable = 150;
	cout<<"new value of stored address: "<<*pntvariable<<endl;*/
	
	//----------------------------------------------------------------------------------
	
	/*int count = 10;
	int*pntvar = &count;
	
	count = count+10;
	*pntvar = *pntvar +10;
	cout<<count<<endl;
    cout<<*pntvar<<endl;*/
    
    //---------------------------------------------------------------------------------------
    
    /*int count = 100;
    int*pcount = &count;
    cout<<"count: "<<count<<endl;
    cout<<"pcount: "<<pcount<<endl;
    cout<<"++pcount: "<<(++pcount)<<endl;
    cout<<"count: "<<count<<endl;*/
   
   //--------------------------------------------------------------------------------------
    
    /*float average = 4.56;
    float*pointer = &average;
    
    cout<<"pointer: "<<pointer<<endl;
    cout<<"*pointer: "<<*pointer<<endl;
    (*pointer) += 5;
    cout<<"new *pointer: "<<*pointer<<endl;;
    cout<<"average: "<<average<<endl;*/
    
    //-----------------------------------------------------------------------------------------
    
    /*int n;
    cout<<"enter the value: ";
    cin>>n;
    cout<<increase(&n)<<endl;
    cout<<"new value: "<<n<<endl;
    cout<<"Adress of new value: "<<&n<<endl;*/
    
    //----------------------------------------------------------------------------------------
    
    /*int array[3] = {33,54,9};
    int*pointer = array;
    
    cout<<"array: "<<array<<endl;
    cout<<"&array: "<<&array<<endl;
    cout<<"&array[0]: "<<&array[0]<<endl<<endl;
    
    for(int i=0; i<3; i++)
    {
    	cout<<pointer + i<<"\t";
	}*/
    
    //--------------------------------------------------------------------------------------
    
    /*const int maxSize = 3;
    int total[maxSize] = {5,39,19};
    int*pointer[maxSize];
    
    for(int count = 0; count<maxSize; count++)
    {
    	pointer[count] = &total[count];
    	cout<<pointer[count]<<"\t";
	}*/
    
    //--------------------------------------------------------------------------------
    
    /*int array[2][3] = { {23,35,32},{76,69,64} };
    int*pointer = &array[0][0];
    
    for(int i=0; i<sizeof(array)/4; i++)
    {
		cout<<pointer + i<<"\t";
	}*/
	
	//------------------------------------------------------------------------------------------
	
	const int rows = 2;
	const int cols = 3;
	int values[rows][cols] = { {2,3,4}, {-4,5,9} };
	
	for(int i=0; i<rows; i++)
	{
		for(int j=0; j<cols; j++)
		{
			cout<<"values: ["<<i<<"]["<<j<<"] = "<<values[i][j]<<"\t";
			cout<<"@ = "<<&values[i][j]<<endl;
		}
		cout<<endl;
	}
	
	
/*	int*pntValue = NULL;
	pntValue = new int;
	*pntValue = 10;
	
	cout<<"pntValue: "<<pntValue<<endl;
	cout<<"*pntValue: "<<*pntValue<<endl;
	cout<<"&pntValue: "<<&pntValue<<endl;
    
    delete pntValue;*/

    
    /*float x1,x2,y1,y2,r1,r2;
    cout<<"Enter the values for x1,x2,y1,y2,r1,r2 respectivly: ";
    cin>>x1,x2,y1,y2,r1,r2;
    
    cout<<"the common area is; "<<commonCircleArea(x1,x2,y1,y2,r1,r2)<<endl;*/
    return 0;
    

}
