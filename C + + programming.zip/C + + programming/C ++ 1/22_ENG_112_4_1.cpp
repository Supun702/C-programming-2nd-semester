#include <iostream>
#include <math.h>
using namespace std;

int parabolaAndLine(float pa,float pb,float pc,float lm,float lc)
{
	float discriminant;
	float root1,root2;
	
	// Find discriminant....
	discriminant = pb*pb - 2*pb*lm + lm*lm - 4*pa*(pc - lc);
	root1 = (-(pb-lm) - sqrt(discriminant))/(2*pa);
	root2 = (-(pb-lm) + sqrt(discriminant))/(2*pa);
	
	if(discriminant>0)
	{
		cout<<"Intersecting points are : "<<"("<<root1<<","<<lm*root1 + lc<<")"<<" and "<<"("<<root2<<","<<lm*root2 + lc<<")"<<endl;
		return -1;
    }
    else if(discriminant==0)
    {
    	cout<<"Touching point : "<<"("<<root1<<","<<lm*root1 + lc<<")"<<endl;
    	return 0;
	}
	else
	{
		cout<<"No intersecting points"<<endl;
		return 1;
	}
}

int main()
{
	float pa,pb,pc,lm,lc;
	
	cout<<"Enter coefficients for the parabola (a.b.c): ";
	cin>>pa>>pb>>pc;
	
	cout<<"Enter coefficients for the line (m,c): ";
	cin>>lm>>lc;
	
	// call the function and get the result....
	int result = parabolaAndLine(pa, pb,pc,lm,lc);
	
	if(result == 0)
	{
		cout<<"line and parabola are touched."<<endl;
	}
	else if(result == -1)
	{
		cout<<"line and parabola are intersected."<<endl;
	}
	else
	{
		cout<<"There is no any intersecting or touching points."<<endl;
	}
	
	return 0;	
}

