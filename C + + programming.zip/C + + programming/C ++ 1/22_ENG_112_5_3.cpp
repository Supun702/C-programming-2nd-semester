#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std; 

const int Rows = 20;
const int Coloms = 5;

void FillArray(float array[Rows][Coloms])
{
	srand(time(0));
	for(int a = 0; a < Rows; a++)
	{
		for(int b = 0; b < Coloms; b++)
		{
			array[a][b] = static_cast<float>(rand()); 
		}
	}
}

void DisplayArray(float array[Rows][Coloms])
{
	for(int a = 0; a < Rows; a++)
	{
		for (int b = 0; b < Coloms; b++)
		{
			cout<< array[a][b] << "\t"; 
		}
		cout<<endl;
	}
}

void BubbleSort(float array[Rows][Coloms], int Col, bool ascending)
{
	for(int a = 0; a < Rows-1; a++)
	{
		for(int b = 0; b < Rows-a-1; b++)
		{
			if((ascending && array[b][Col] > array[b+1][Col]) || (!ascending && array[b][Col] < array[b+1][Col]))
			{
				for(int c = 0; c < Coloms; c++)
				{
					swap(array[b][c], array[b+1][c]);
				}
			}
		}
	}
}

int main()
{
	float array[Rows][Coloms];
	FillArray(array);
	
	char SelectColom;
	cout<<"Enter the colom to sort (A,B,C,D or E): ";
	cin>> SelectColom;
	
	int Index = SelectColom - 'A'; //Convert colom letter to index....
	if( Index < 0 || Index >= Coloms)
	{
		cout<<"Invalid colom selection."<<endl;
		return 1;
	}
	
	string Order;
	cout<<"Enter ASC for ascending or DESC for descending: ";
	cin>> Order;
	
	bool ascending = Order == "ASC";
	
	BubbleSort(array, Index, ascending);
	
	cout<<"Sorted array: "<<endl;
	DisplayArray(array);
	
	return 0;
}

















