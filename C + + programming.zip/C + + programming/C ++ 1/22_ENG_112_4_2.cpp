#include <iostream>
using namespace std;

void printTriangle (int rows) //Print Triangle....
{
	if(rows < 5 || rows > 15)
	{
		cout<<"Invalid number of rows. Enter a row value between 5 and 15."<<endl;
		return;
	}
	
	for(int i=1; i <= rows; ++i)
	{
		for(int j=1; j <= i; ++j)
		{
			cout<< "* ";
		}
		cout<<endl;   
	}		
}

void printTriangle(int rows, char ch) //Print Triangle with Character....
{
	if(rows < 5 || rows > 15)
	{
		cout<<"Invalid number of rows. Enter a row value between 5 and 15."<<endl;
		return;
	}
	
	for(int i=1; i <= rows; ++i)
	{
		for(int j=1; j <= i; ++j)
		{
			cout<< ch <<" ";
    	}
    	cout<<endl;
    }
}

void printTriangle(int rows, bool border) //Print Triangle with Border....
{
    if (rows < 5 || rows > 15) 
	{
        cout<<"Invalid number of rows. Enter a row value between 5 and 15."<<endl;
        return;
    }

    for (int i=1; i <= rows; ++i) 
	{
        for (int j=1; j <= i; ++j) 
		{
            if (border && (i == 1 || i == rows || j == 1 || j == i)) 
			{
                cout<<"* ";
            } 
			else 
			{
                cout<<"  ";
            }
        }
        cout<<endl;
    }
}


int main()
{
	int option;
	do
	{
		cout<<"1. Print Triangle"<<endl;
		cout<<"2. Print Triangle with Character"<<endl;
		cout<<"3. Print Triangle with Border"<<endl;
		cout<<"4. Exit"<<endl;
		cout<<"Enter your choice: ";
		cin>> option;
		
		switch(option)
		{
			case 1:
				int rows1;
				cout<<"Enter the number of rows (5-15): ";
				cin>> rows1;
				printTriangle(rows1);
				break;
			
			case 2:
				int rows2;
				char ch;
				cout<<"Enter the number of rows (5-15): ";
				cin>> rows2;
				cout<<"Enter the character: ";
				cin>> ch;
				printTriangle(rows2, ch);
				break;
			
			case 3:
				int rows3;
                bool border;
                cout<<"Enter the number of rows (5-15): ";
                cin>> rows3;
                cout<<"Include border? (1 for true, 0 for false): ";
                cin>> border;
                printTriangle(rows3, border);
                break;
			
			case 4:
				cout<<"Exit program."<<endl; //Exit....
				break;
			default:
				cout<<"Invalid choice."<<endl;		
		}
	}
	while(option != 4);
	
	return 0;
}
