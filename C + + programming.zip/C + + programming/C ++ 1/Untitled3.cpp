#include <iostream>

void printTriangle(int rows) {
    if (rows < 5 || rows > 15) {
        std::cout << "Invalid number of rows. Please enter a value between 5 and 15.\n";
        return;
    }

    for (int i = 1; i <= rows; ++i) {
        for (int j = 1; j <= i; ++j) {
            std::cout << "* ";
        }
        std::cout << "\n";
    }
}

void printTriangle(int rows, char ch) {
    if (rows < 5 || rows > 15) {
        std::cout << "Invalid number of rows. Please enter a value between 5 and 15.\n";
        return;
    }

    for (int i = 1; i <= rows; ++i) {
        for (int j = 1; j <= i; ++j) {
            std::cout << ch << " ";
        }
        std::cout << "\n";
    }
}

void printTriangle(int rows, bool border) {
    if (rows < 5 || rows > 15) {
        std::cout << "Invalid number of rows. Please enter a value between 5 and 15.\n";
        return;
    }

    for (int i = 1; i <= rows; ++i) {
        for (int j = 1; j <= i; ++j) {
            if (border && (i == 1 || i == rows || j == 1 || j == i)) {
                std::cout << "* ";
            } else {
                std::cout << "  ";
            }
        }
        std::cout << "\n";
    }
}

int main() {
    int option;
    do {
        std::cout << "1. Print Triangle\n";
        std::cout << "2. Print Triangle with Character\n";
        std::cout << "3. Print Triangle with Border\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> option;

        switch (option) {
            case 1:
                int rows1;
                std::cout << "Enter the number of rows (5-15): ";
                std::cin >> rows1;
                printTriangle(rows1);
                break;
            case 2:
                int rows2;
                char ch;
                std::cout << "Enter the number of rows (5-15): ";
                std::cin >> rows2;
                std::cout << "Enter the character: ";
                std::cin >> ch;
                printTriangle(rows2, ch);
                break;
            case 3:
                int rows3;
                bool border;
                std::cout << "Enter the number of rows (5-15): ";
                std::cin >> rows3;
                std::cout << "Include border? (1 for true, 0 for false): ";
                std::cin >> border;
                printTriangle(rows3, border);
                break;
            case 4:
                std::cout << "Exiting program.\n";
                break;
            default:
                std::cout << "Invalid choice. Please enter a valid option.\n";
                break;
        }
    } while (option != 4);

    return 0;
}
