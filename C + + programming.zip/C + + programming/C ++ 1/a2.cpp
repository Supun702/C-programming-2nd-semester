#include <iostream>
using namespace std;

int main()
{
	/*int i;
	cout<<"Enter the number: ";
	cin>>i;
	while(i)
	{
		cout<<i<<"\t";
		i++;
	}
	cout<<"End of loop"<<endl;*/
	
	/*int i;
	do
	{
		cout<<"Enter the number between 1 and 8: ";
		cin>>i;
	}
	while(i<=1 || i>=8);
	cout<<"Valid number"<<endl;*/
	
	/*float l,w, area=0;
	char ch;
	
	do
	{
		cout<<"Please enter the length & width: ";
		cin>>l>>w;
		area = l*w;
		cout<<"The area is: "<<area<<endl;
		cout<<"\nDo you need to calculate another area ???"<<endl;
		cout<<"Press 'Y' or 'y for yes, Press 'N' or 'n' for no...";
		cin>>ch; 
	}
	while(ch == 'Y' || ch =='y');
	cout<<"\nOut of programme"<<endl;*/
	
    float i,j,k;
	char ch;
	
	do
	{
		cout<<"1 for addition"<<endl;
		cout<<"2 for substraction"<<endl;
		cout<<"3 for multiplication"<<endl;
		cout<<"4 for devision"<<endl;
		cout<<"Q for quit"<<endl;
		
		cout<<"\nEnter your choise: ";
		cin>>k;
		if(k==1)
		{
			cout<<"Enter your numbers: ";
			cin>>i>>j;
			cout<<i+j<<endl;
		}
		else if (k==2)
		{
			cout<<"Enter your numbers: ";
			cin>>i>>j;
			cout<<i-j<<endl;
		}
		else if (k==3)
		{
			cout<<"Enter your numbers: ";
			cin>>i>>j;
			cout<<i*j<<endl;
		}
		else if (k==4)
		{
			cout<<"Enter your numbers: ";
			cin>>i>>j;
			cout<<i/j<<endl;
		}
		else
		{
			cout<<"Invalid choosen"<<endl;
		}
	}
	while(k>=4 || ch == 'Q' || ch == 'q');
	cout<<"Quit"<<endl;

	return 0;
}
