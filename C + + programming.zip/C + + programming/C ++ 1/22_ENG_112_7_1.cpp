#include <iostream>
#include <math.h>
#include <unordered_map>
#include <algorithm>
#include <vector>
using namespace std;

void getMoviesData (int*movies, int size)
{
	for(int i=0; i<size; i++)  //create an array..
	{
		cout<<"Enter the number of movies for student "<<i+1<<": ";
		cin>> movies[i];
	}
}

float calculateMean (int*movies, int size)
{
	float sum=0;
	for(int i=0; i<size; i++)  //calculate the mean...
	{
		sum += movies[i];
	}
	return sum/size;
}

float calculateMedian (int*movies, int size)
{
	for(int i=0; i<size-1; i++)  //sort the array...
	{
		for(int j=0; j<size-i; i++)
		{
	    	int temp=0;
		    if(movies[j]>movies[j + 1])
		    {
		    	int temp = movies[j];
			    movies[j] = movies[j + 1];
			    movies[j + 1] = temp;
		    }
	    }
    }
	
	if(size %2 == 0)
	{
		return static_cast<float>(movies[(size/2) - 1] + movies[size/2])/2;
	}
	else
	{
		return static_cast<float>(movies[(size+1)/2 -1]);
	}
}

int calculateMode (int*movies, int size)
{
	unordered_map<int, int> frequencyMap;  //get the mode of an array...
	
	for(int i=0; i<size; i++)
	{
		frequencyMap[movies[i]]++;
	}
	
	int mode=0;
	int maxFrequency=0;
	
	for(const auto &entry : frequencyMap)
	{
		if(entry.second > maxFrequency)
		{
			maxFrequency = entry.second;
			mode = entry.first;
		}
	}
	return mode;
}

float calculateVariance (int*movies, int size, float*variance)
{
	float mean = calculateMean(movies, size);
	*variance =0; 
	
	for(int i=0; i<size; i++)
	{
		*variance += pow(movies[i] - mean,2);
	}
	*variance /= size;
	
	return*variance;  //calculate the variance...
}


int main()
{
	char option = 'y';
	do
	{
	int numStudents;
	
	cout<<"Enter the number of students surveyed: ";
	cin>> numStudents;
	
	int*movies = new int[numStudents]; //dynamically allocate an array...
	
	getMoviesData(movies, numStudents);
	
	cout<<"Mean: "<<calculateMean(movies, numStudents)<<endl;
	cout<<"Median: "<<calculateMedian(movies, numStudents)<<endl;
	cout<<"Mode: "<<calculateMode(movies, numStudents)<<endl;
	
	float variance;
	cout<<"Variance: "<<calculateVariance(movies, numStudents, &variance)<<endl;
	cout<<"Standard Deviation: "<<sqrt(variance)<<endl;
	
	delete[] movies;
	
	cout<<"\nDo you want to continue enter y or not enter n: ";
	cin>> option;
	
    }while(option != 'n');
  
	return 0;
    
}









