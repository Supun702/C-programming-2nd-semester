#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int main()
{
	double LoanAmount, AnnualInterestRate, r, PaymentAmount;
	int NumberOfPayments;
	  
	cout<<"Enter the loan amount: ";
	cin>> LoanAmount;
	
	cout<<"Enter the annual interest rate: ";
	cin>> AnnualInterestRate;
	r = AnnualInterestRate/100; // interest rate to decimal
	
	cout<<"Enter the number of payments: ";
	cin>> NumberOfPayments;
	
	PaymentAmount = LoanAmount*(r*pow(1+r, NumberOfPayments))/(pow(1+r, NumberOfPayments) -1);
	//Calculate monthly payment  
	cout<<"The total monthly payment amount is: "<< fixed<< setprecision(2)<< PaymentAmount<<endl;
	return 0;
	
}
