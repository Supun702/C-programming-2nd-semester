#include <iostream>
#include <vector>
using namespace std;

int main()
{ 
  double Totalresistance, Voltage, Totalcurrent; 
  vector<double> resistance(3); //Input resistance for the three resistors
  
  cout<<"Enter the resistance of the three resistors in ohms:"<<endl;
  for(int a = 0; a<3; ++a)
  {
    cout<<"Resistor "<< a+1 << " resistance: ";
    cin>> resistance[a];	
  }
  
  //Calculate Total Resistance
  Totalresistance = 1/(1/resistance[0] + 1/resistance[1] + 1/resistance[2]);
  
  Voltage = 5.0; //Battery Voltage
  
  //Calculate Total Current
  Totalcurrent = Voltage/Totalresistance;
  cout<<"The total current passing throuugh the LED is: "<<Totalcurrent<< "amperes."<<endl;
  return 0; 
  
}
  
