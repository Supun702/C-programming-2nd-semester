#include<iostream>
#include<math.h>
using namespace std;


double calculateFixedReturn(double loan, double annualInterestRate, int years)
{
	double monthlyLoan = loan/(12*years);
	double monthlyInterestRate = annualInterestRate/100/12;
	
	double monthlyPayment = monthlyLoan*100/monthlyInterestRate;
	double totalReturn = 12*years*(monthlyPayment - monthlyLoan);
	
	return totalReturn; 
	
}

int main()
{
	double loan, annualInterestRate;
	int years;
	
	cout<<"Enter the loan amount: ";
	cin>>loan;
	
	cout<<"Enter the annualInterestRate: ";
	cin>>annualInterestRate;
	
	cout<<"Enter the number of years: ";
	cin>>years;
	
	cout<<"Total return is: "<<calculateFixedReturn(loan, annualInterestRate, years);
	
	
    return 0;
}






