#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{	
/*	for(int row=1; row<=1; row++)
	{
		for(int k=1; k<=1; k++)
		{
			cout<<"*\t";
	    }
	    for(int col=1; col<=13; col++)
	    {
	    	cout<<col<<"\t";
	    }
	}
	
	for(int row=1; row<=1; row++)
	{
		cout<<" "<<endl;
		
		for(int col=1; col<=13; col++)
		{
			cout<<col<<endl;
		}
		
    }*/
    
    //-------------------------------------------------------------------------
    
    /*const int rows = 13;
    const int colums = 13;
    int multiplicationTable[rows][colums];
    
    for(int i=1; i<=13; i++)
    {
    	for(int j=1; j<=13; j++)
    	{
    		multiplicationTable[i-1][j-1] = i*j;
		}
	}
	    
	for(int a=1; a<=rows; a++)
	{
		cout<<"\t";
	    for(int j=1; j<=colums; j++)
	    {
	    	cout<<multiplicationTable[a-1][j-1]<<"\t";
	    }
	    cout<<endl;
	}*/
	
	//-----------------------------------------------------------------------------------------------
	
	/*srand(time(0));
	
	int array[3][2];
	for(int i=1; i<=3; i++)
	{
		for(int j=1; j<=2; j++)
		{
			array[i][j] = rand()%100;
		}
	}
	
	for(int k=1; k<=3; k++)
	{
		for(int a=1; a<=2; a++)
		{
			cout<<array[k][a]<<"\t";
		}
		cout<<endl;
	}*/
	
	//-------------------------------------------------------------------------------
	
	/*const int rows = 2;
	const int cols = 3;
	
	int originalMatrix[rows][cols] = { {1,2,3} , {4,5,6} };
	
	int transposeMatrix[cols][rows];
	
	for(int i=1; i<=2; i++)
	{
		for(int j=1; j<=3; j++)
		{
			transposeMatrix[j-1][i-1] = originalMatrix[i-1][j-1];
		}
	}
	
	cout<<"Original matrix..."<<endl;
	for(int i=1; i<=2; i++)
	{
		for(int j=1; j<=3; j++)
		{
			cout<<originalMatrix[i-1][j-1]<<"\t";
		}
		cout<<endl;
	}
	
	cout<<"Transpose matrix..."<<endl<<endl;;
	for(int i=1; i<=3; i++)
	{
		for(int j=1; j<=2; j++)
		{
			cout<<transposeMatrix[i-1][j-1]<<"\t";
		}
		cout<<endl;
	}*/
	
	//-------------------------------------------------------------------------------------
	
	int matA[2][2] = {{2,1}, {2,1}};
	int matB[2][2] = {{1,1}, {2,1}};
	int matMul[2][2];
	
	for(int i=0; i<2; i++)
	{
		for(int j=0; j<2; j++)
		{
			matMul[i][j] = 0;
			for(int k=0; k<2; k++)
			{
				matMul[i][j] += matA[i][k]*matB[k][j];
			}
		}
	}
	
	for(int i=0; i<2; i++)
	{
		for(int j=0; j<2; j++)
		{
			cout<<matMul[i][j]<<"\t";
		}
		cout<<endl;
	}
	
	
	return 0;
}
