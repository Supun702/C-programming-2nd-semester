#include <iostream>
using namespace std;

int main()
{
	
  int unitsConsumed;
  int DomesticfixCharge[] = {10, 15, 20, 25, 40}; // fix charge values for units consumed
  int BusinessfixCharge[] = {15, 25, 35, 45, 70};
  float totalBill, totalPrice;
  string consumerType;
 
  cout<<"Enter consumer type Domestic or Business: ";
  cin>> consumerType;

  
  if(consumerType == "Domestic")
  {
     cout<<"Enter the units consumed: ";
     cin>> unitsConsumed;
     
     
     if(unitsConsumed >= 0 && unitsConsumed <= 50)
	 {
	 	totalPrice = 0.55*unitsConsumed;
     	totalBill = totalPrice + DomesticfixCharge[0]; 

     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<DomesticfixCharge[0]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;	
     }
     else if(unitsConsumed <= 100 && unitsConsumed > 50)
	 {
     	totalPrice = 0.55*50 + 0.80*(unitsConsumed - 50);
     	totalBill = totalPrice + DomesticfixCharge[1]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<DomesticfixCharge[1]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
     }
     else if(unitsConsumed <= 150 && unitsConsumed > 100)
	 {
     	totalPrice = 0.55*50 + 0.80*50 + 1.05*(unitsConsumed - 100);
     	totalBill = totalPrice + DomesticfixCharge[2]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<DomesticfixCharge[2]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
	 } 
     else if(unitsConsumed <= 200 && unitsConsumed > 150)
	 {
     	totalPrice = 0.55*50 + 0.80*50 + 1.05*50 + 1.35*(unitsConsumed - 150);
     	totalBill = totalPrice + DomesticfixCharge[3]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<DomesticfixCharge[3]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
     } 
     else 
	 {
     	totalPrice = 0.55*50 + 0.80*50 + 1.05*50 + 1.35*50 + 1.75*(unitsConsumed - 200);
     	totalBill = totalPrice + DomesticfixCharge[4]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<DomesticfixCharge[4]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
     } 
  }
  else if (consumerType == "Business")
  {
     cout<<"Enter the units consumed: ";
     cin>> unitsConsumed;
                                                         
     if(unitsConsumed <= 50)
	 {
     	totalPrice = 0.75*unitsConsumed;
     	totalBill = totalPrice + BusinessfixCharge[0]; 

     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<BusinessfixCharge[0]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl; 	
     }
     else if(unitsConsumed <= 100  && unitsConsumed > 50)
	 {
     	totalPrice = 0.75*50 + 1.15*(unitsConsumed - 50);
     	totalBill = totalPrice + BusinessfixCharge[1]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<BusinessfixCharge[1]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
     }
     else if(unitsConsumed <= 150  && unitsConsumed > 100)
	 {
     	totalPrice = 0.75*50 + 1.15*50 + 1.60*(unitsConsumed - 100);
     	totalBill = totalPrice + BusinessfixCharge[2]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<BusinessfixCharge[2]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
	 } 
     else if(unitsConsumed <= 200  && unitsConsumed > 150)
	 {
     	totalPrice = 0.75*50 + 1.15*50 + 1.60*50 + 2.00*(unitsConsumed - 150);
     	totalBill = totalPrice + BusinessfixCharge[3]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<BusinessfixCharge[3]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
     } 
     else
	 {
     	totalPrice = 0.75*50 + 1.15*50 + 1.60*50 + 2.00*50 + 2.65*(unitsConsumed - 200);
     	totalBill = totalPrice + BusinessfixCharge[4]; 
     
     	cout<<"The charges for electricity consumption is: $"<<totalPrice<<endl;
     	cout<<"Fixed charge is: $"<<BusinessfixCharge[4]<<endl;
     	cout<<"The total bill is: $"<<totalBill<<endl;
     } 
  }
  else
  {
     	cout<<"you entered wrong consumer type."<<endl;
  }
    
  return 0;
}
