//NAME   - P.D.S.CHAMARA
//INDEX  - 22/ENG/112
//MODULE - PROGRAMMING FOR ENGINEERS

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

float formularProcessor(const char*array);
bool operatorCheck(char s);
float generateTheOperation(int finalAnswer1, int number, char operation);

int main(int argc, char*argv[])
{
	rename("22_ENG_112_6_1.exe","simplecalculator.exe");     //rename the .exe file.....
	
	if(argc>2)
	{
		cout<<"Error... Spaces are not allowed to the formula"<<endl;    //to check one parameter is passed...
		return 1;
	}
	
	const char*array = argv[1];      //declare the char*array and argv[1] and it assigned...
	
	if(array[strlen(array)-1] != '=')      //check the equal sign...
	{
		cout<<"Error... Formular does not ended up with an equal sign"<<endl;
		return 1;
	}
	
	for(int s=0; s<strlen(array)-1; s++)
	{
		if(isalpha(array[s]))   //check there are any alphabatical character in programme...
		{
			cout<<"Error... Alphabatical character are not allowed"<<endl;
			return 1;
		}
		else if(array[s] == '.')  //check there is a dot...
		{
			cout<<"Error... Dot is not allowed"<<endl;
			return 1;
		}
		if((argv[1]) == NULL)  //check there is a space...
		{
			cout<<"No input formula"<<endl;
			return 1;
		}
	}
	
	cout<<"Result of the formula = "<<formularProcessor(array)<<endl;     //display output...
	
	return 0;
}

float generateTheOperation(float finalAnswer1, float number, char operation)
{
	switch(operation)
	{
		case '+':
			return finalAnswer1 + number;      //calculate the addditon..
			break;
			
		case '-':
			return finalAnswer1 - number;     //calculate the substraction...
			break;
			
		case '*':
			return finalAnswer1 * number;     //calculate the multiplication...
			break;
			
		case '/':
			if(number != 0)                   //calculate the devision...
			{
				float result, finalAnswer2;
				finalAnswer2 = finalAnswer1;
				result = finalAnswer2/number;
				return result;
			}
			else
			{
				cout<<"Can't devision by zero"<<endl;
				exit(1);
			}
			break;
		
		case '%':                                //calculate the modular..
			int reFinalAnswer1 = finalAnswer1;
			int reNumber = number;
			return reFinalAnswer1 % reNumber;
			break;
			
	/*	default:
			cout<<"Error... Invalid operator"<<endl;
			exit(1);
			break;*/
		
	}
}

bool operatorCheck(char s)   //identify the operator in the array...
{
	return (s == '+' || s == '-' || s == '*' || s == '/' || s == '%');
}

float formularProcessor(const char*array)
{
	float number = 0;
	float finalResult = 0;       //declare the array...
	char operation = '+';
	bool num = false;
	
	for(int s=0; s<strlen(array)-1; s++)
	{
		char character2 = array[s];         //assign character to a variable...
		if(isdigit(character2))
		{
			number = number*10 + (character2 - '0');
			num = true;
		}
		else if(operatorCheck(character2))
		{
			finalResult = generateTheOperation(finalResult, number, operation);       //calculate the answer...
			number=0;
			operation = character2;
			num = false;
		}
		else if(character2 == '[' || character2 == '(')
		{
			int noOfOpenBrackets = 1;
			int c;
			
			for(int c = s+1; c<strlen(array)-1 && noOfOpenBrackets>0; c++)
			{
				if(array[c] == '(')
				{
					noOfOpenBrackets++;
				}
				else if(array[c] == ')' || array[c] == ']')
				{
					noOfOpenBrackets--;
				}
			}
			
			if(noOfOpenBrackets != 0)
			{
				cout<<"Error... Closing brackets does not exist"<<endl;
				exit(1);
			}
			number = formularProcessor(array + s + 1);
			 s =c-1;
			num = true;
		}
	}
	
	return generateTheOperation(finalResult, number, operation);          //return the generateTheOperation function...
}
















