#include <iostream>
using namespace std;

int main() 
{ 
  int CarbonAtoms;
  cout<<"Enter the number of carbon atoms: ";
  cin>>CarbonAtoms;
  
  if(CarbonAtoms % 2 == 0){
  	cout<<"Multiplying factor of CO2 is: "<< CarbonAtoms*2<<endl;
  	cout<<"Multiplying factor of Hydro-Carbon is: 2"<<endl;
  	cout<<"Multiplying factor of H2O is: "<< (CarbonAtoms*2 + 2)<<endl;
  	cout<<"Multiplying factor of O2 is: "<< (CarbonAtoms*3 + 1)<<endl<<endl;
  	
  	cout<<"Hydro-Carbon burning reaction equation is"<<endl; //develop a burning equation
  	cout<<"2"<<"C"<<CarbonAtoms<<"H"<<(CarbonAtoms*2 + 2)<<" "<<"+"<<" "<<(CarbonAtoms*3 + 1)<<"O2"<<" "<<"------->"<<" "<<(CarbonAtoms*2 + 2)<<"H2O"<<" "<<"+"<<" "<<CarbonAtoms*2<<"CO2";
  }
  else{
  	cout<<"Multiplying factor of CO2 is: "<< CarbonAtoms<<endl;
	cout<<"Multiplying factor of Hydro-Carbon is: 1"<<endl;
	cout<<"Multiplying factor of H2O is: "<< (CarbonAtoms + 1)<<endl;
	cout<<"Multiplying factor of O2 is: "<< (CarbonAtoms*3 + 1)/2 <<endl<<endl; 
	
	cout<<"Hydro-Carbon burning reaction equation is"<<endl; //develop a burning equation
  	cout<<"C"<<CarbonAtoms<<"H"<<(CarbonAtoms*2 + 2)<<" "<<"+"<<" "<<(CarbonAtoms*3 + 1)/2<<"O2"<<" "<<"------->"<<" "<<(CarbonAtoms + 1)<<"H2O"<<" "<<"+"<<" "<<CarbonAtoms<<"CO2";
  }
  return 0;
}
