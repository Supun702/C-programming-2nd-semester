#include <iostream>
#include <iomanip>
#include <limits>
using namespace std;



int main()
{
	//unsigned short int main = 65535;
	//unsigned short int include = 65536;
	//unsigned short int cin = 65538;
	//float a = 1.2345914000;
	//long double b = 223.45678910111213141516171819L;
	
	//cout<< setprecision (10);
	//cout<<"main is: "<<main<<"\n"<<"include is: "<<include<<"\n"<<"cin is: "<<cin<<endl;
	//cout<<"float a is: "<<a<<endl;
	//cout<<"long double b is: "<<b<<endl;
	
	//cout<<numeric_limits<float>::digits10<<endl;
	//cout<<numeric_limits<long double>::digits10<<endl;
	
	/*int x=10, y=12;
	int z= x+ y+true + false;
	
	if( (x>y) == true)
	{
		cout<<"x is higher than y"<<endl;
	}
	else
	{
		cout<<"y is higher than x"<<endl;
	}
	
	
	
	
	/*void *ptr;
	int x=10;
	ptr = &x;
	
	cout<<*(int*)ptr<<endl;*/
	
	/*int i=10,sum,mul;
	for(; i>=1; i--)
	{
		sum += i;	
		cout<<i<<endl;
	}
	
	cout<<"\nThe sum of 1 to 10 numbers: "<<sum<<endl;*/
	
	/*int i,j;
	for(i=1,j=10;i<=10,j>=1;i++,j--)
	{
		cout<<i<<"\t"<<j<<endl;
		
	}*/
	
	/*int i,sum=0;
	for(i=1; i<=10; i+=2)
	{
		sum += i;
		cout<<i<<endl;
	
	
	}
	
	cout<<"The sum of odd numbers in 1 to 10: "<<sum<<endl; */
	
	/*char ch;
	cout<<"Please enter the character: ";
	cin>>ch;
	
	switch(ch)
	{
		case 'a':
		case 'A':
			cout<<"Apple";
			break;
		case 'b':
			cout<<"Ball";
			break;
		default:
			cout<<"Input correct symbole"<<endl;
			break;
	}*/
	
	/*int i=1;
	cout<<"Input number: ";
	cin>>i;
	while(i<=1 || i>=5)
	{
		cout<<"Please enter the number between 1 & 5: ";
		cin>>i;
		
	}
	cout<<"Thanks"<<endl;*/
	
	/*int n;
	bool i=false;
	while(!i)
	{
		cout<<"Please enter the number between 2 and 9: ";
		cin>>n;
		if(n<=2 || n>=9)
		{
			cout<<"You entered wrong number"<<endl;
		}
		else
		{
			cout<<"Valid number"<<endl;
			i = true;
		}
	}*/
	
	/*int i;
	cout<<"Enter the number: ";
	cin>>i;
	while(i)
	{
		cout<<i<<"\t";
		i++;
	}
	cout<<"End of loop"<<endl;*/ 
	
	//cout<<"hello world \u0040"<<endl;
	
	//---------------------------------------------------------------------------------------
	
	/*int number;                  //print factorial value....
	long long factorial = 1;
	
	cout<<"Enter the number: ";
	cin>>number;
	
	for(int i=1; i<=number; ++i)
	{
		factorial = factorial*i;
	}
	cout<<"Factorial value is: "<<factorial;*/
	
	//----------------------------------------------------------------------------------------
	
	int n;
	cout<<"enter the value of n: ";
	cin>>n;
	
	int i,next=0,second=1,first=0,sum1=0,sum2=0;
	
	for(i=1; i<=n; ++i)
	{
		if(i<=1)                           //fibonacci series.....
		{
			next=i;
		}
		else
		{
		    next= first + second;
		    first= second;
		    second= next;
		}
		
		cout<<next<<",";
		sum1 = sum1 + second;
		sum2 = sum2 + first;	
	}
	
	    cout<<"\n\nThe nth value is: "<<sum1 - sum2<<endl;
	
	//--------------------------------------------------
	
	/*for(int row=1; row<= 5; ++row)
	{
		for(int col=1; col<row; ++col)
		{
			cout<<" ";
		}
	    cout<<"*"<<endl;	
	}*/
	
	//---------------------------------------------
	
   /* for(int row=1; row<=4; ++row)
    {
    	for(int spc=1; spc<= 4-row; ++spc)
    	{
    		cout<<" ";
		}
		for(int k=1; k<=row; ++k )
		{
			cout<<"*";
		}
		cout<<endl;
	}*/
	
	/*
	int row=1;
	do
	{
		for(int spc=1; spc<=row; ++spc)
    	{
    		cout<<"*";                                    *
		}                                                 **
		cout<<endl;                                       ***
		++row;                                            ****
	}                                                     *****
	while( row<=5);                                       ****
                                                          ***           
    row= 5;                                               **
    do                                                    *
    {                                                    
    	for(int spc=1; spc<row; ++spc)
    	{
    		cout<<"*";
		}
		cout<<endl;
		--row;
	}
	while( row>0);*/
	
	/*int row=1;
	do
	{
		for(int col=1; col<=row; ++col)
		{
			cout<<col;
		}
		++row;
		cout<<endl;
	}
	while(row<=5);*/
	
	//--------------------------------------------------------------
	
	/*int row=5;
	do
	{
		for(int col=1; col<row; ++col)
		{
			cout<<" ";
		}
		for(int k=row; k<=5; ++k)
		{
			cout<<k;
		}
		cout<<endl;
		--row;
	}
	while(row>=1);*/
	
	//--------------------------------------------------------------------------
	
	/*int n;
	cout<<"Please enter the number of n: ";
	cin>>n;
	
	for(int row=1; row<=n; ++row)
	{
		for(int col=1; col<=row; ++col)
		{
				if(row==1 || col== 1 || row== n || row==col)
				{
					cout<<"*";
				}
				else
				cout<<" ";
	    }
	    cout<<endl;
	}*/
	
	//---------------------------------------------------------
	
	/*int n,y;
	cout<<"Please enter the number of rows: ";
	cin>>n;
	cout<<"Please enter the number of coloums: ";
	cin>>y;
	
	for(int row=1; row<=n; ++row)
	{
		for(int col=1; col<=y; ++col)
		{
			cout<<"+-";
		}
		cout<<endl;
		
		for(int k=1; k<=y; ++k)
		{
			cout<<"-+";
		}
		cout<<endl;
	}*/
	
	//********************************************************
	
	/*int row=1;
	do
	{
		int col=1;
		do
		{
			cout<<"*";
		
		++col;
	    }
		while(col<=row);
		
		cout<<endl;
		++row;
	}
	while(row<=5);*/
	
	//********************************************************************
	
	int row=5;
	do
	{
		int col=1;
		do
		{
			cout<<" ";
		
		++col;
	    }
		while(col<=row);
		
		int k=row;
		do
		{
			cout<<k;
		
		++k;
		}
		while(k<=5);
		
	    cout<<endl;
	--row;	
	}
	while(row>=1);
	
    //cout << "\u0049 \u004C\u004F\u0056\u0045\u0020\u0059\u004F\u0055" <<endl;
    
 
	return 0;
}
	









