#include<iostream>
#include<algorithm>
#include<vector>
#include<string>

using namespace std;

class Apartment 
{
  public:
    int number;
    int doors;
    int windows;
    int rooms;
    int washrooms;
    double floorArea;
    double buildingCost;

    Apartment(int num, int d, int w, int r, int wash, double area, double cost)
        : number(num), doors(d), windows(w), rooms(r), washrooms(wash), floorArea(area), buildingCost(cost) {}
};

class HousingComplex 
{
    public:
    char name;
    vector<Apartment*> apartments;

    HousingComplex(char n) : name(n) {}

    ~HousingComplex() {
        for (Apartment* apt : apartments) {
            delete apt;
        }
        apartments.clear();
    }
};

bool compareApartmentsByArea(const Apartment* a, const Apartment* b) 
{
    return a->floorArea < b->floorArea;
}

bool compareApartmentsByCost(const Apartment* a, const Apartment* b) 
{
    return a->buildingCost < b->buildingCost;
}

int main() 
{
    vector<HousingComplex*> housingProjects;
    
    // Function to display details of all apartments or a specific apartment
    auto displayApartments = [](HousingComplex* complex) 
	{
        for (Apartment* apt : complex->apartments) 
		{
            cout << "Apartment " << apt->number << " - Floor Area: " << apt->floorArea
                 << ", Building Cost: " << apt->buildingCost << endl;
        }
    };

    // User input validation
    auto getInputInRange = [](int min, int max, const string& prompt) 
	{
        int input;
        do 
		{
            cout << prompt;
            cin >> input;
            if (cin.fail() || input < min || input > max) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input. Please enter a number between " << min << " and " << max << "." << endl;
            } else {
                break;
            }
        } while (true);
        return input;
    };

    // Housing projects creation
    for (char complexName = 'A'; complexName <= 'G'; ++complexName) 
	{
        HousingComplex* complex = new HousingComplex(complexName);

        for (int aptNum = 1; aptNum <= 12; ++aptNum) 
		{
            // Assuming user input validation for apartment details
            int doors, windows, rooms, washrooms;
            double floorArea, buildingCost;

            // Get details from the user
            cout << "Enter details for Apartment " << aptNum << " in Housing Complex " << complexName << ":" << endl;
            doors = getInputInRange(1, 10, "Number of doors: ");
            windows = getInputInRange(1, 10, "Number of windows: ");
            rooms = getInputInRange(1, 10, "Number of rooms: ");
            washrooms = getInputInRange(1, 5, "Number of washrooms: ");
            floorArea = getInputInRange(50, 500, "Floor area (in square meters): ");
            buildingCost = getInputInRange(10000, 500000, "Estimated building cost: ");

            // Create Apartment object
            Apartment* apt = new Apartment(aptNum, doors, windows, rooms, washrooms, floorArea, buildingCost);

            // Add apartment to the complex
            complex->apartments.push_back(apt);
        }

        // Add complex to the list of housing projects
        housingProjects.push_back(complex);
    }

    // User interaction
    char choice;
    do 
	{
        cout << "Select an ongoing housing complex project (A to G) or enter 'Q' to quit: ";
        cin >> choice;
        choice = toupper(choice);

        if (choice >= 'A' && choice <= 'G') 
		{
            // Display details of all apartments in the selected complex
            displayApartments(housingProjects[choice - 'A']);

            // Sort and display apartments by floor area in ascending order
            sort(housingProjects[choice - 'A']->apartments.begin(), housingProjects[choice - 'A']->apartments.end(), compareApartmentsByArea);
            cout << "\nApartments sorted by floor area in ascending order:" << endl;
            displayApartments(housingProjects[choice - 'A']);

            // Sort and display apartments by building cost in descending order
            sort(housingProjects[choice - 'A']->apartments.begin(), housingProjects[choice - 'A']->apartments.end(), compareApartmentsByCost);
            reverse(housingProjects[choice - 'A']->apartments.begin(), housingProjects[choice - 'A']->apartments.end());
            cout << "\nApartments sorted by building cost in descending order:" << endl;
            displayApartments(housingProjects[choice - 'A']);
        } 
		else if (choice != 'Q') 
		{
            cout << "Invalid input. Please enter a valid housing complex project letter (A to G) or 'Q' to quit." << endl;
        }
    } while (choice != 'Q');

    // Clean up dynamically allocated memory
    for (HousingComplex* complex : housingProjects) 
	{
        delete complex;
    }

    return 0;
}








