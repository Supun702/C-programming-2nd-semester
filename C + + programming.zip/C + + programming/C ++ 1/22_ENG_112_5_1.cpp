#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

void displayArray(int arr[], int size)
{
	for(int a = 0; a < size; a++)
	{
		cout<<arr[a] << " ";
	}
	cout<<endl;
}

void cardSort(int arr[], int size)
{
	for(int a = 1; a < size; a++)
	{
		int currentCard = arr[a];
		int b = a-1;
		
		while(b >= 0 && arr[b] >currentCard)
		{
			arr[b+1]= arr[b];
			b--;
		}
		
		arr[b + 1] = currentCard;
		
		//Display the array after the card movement....
		cout<<"After picking card"<< currentCard << ": ";
		displayArray(arr, size);
	}
}

int main()
{
	int arraySize = 11;
	int cards[arraySize];
	
	//seed the random number generator....
	srand(time(0));
	
	for(int a = 0; a < arraySize; a++)
	{
		cards[a] = rand()%20; //Generating random number between 0 and 20....
	}
	
	cout<<"Initial array: ";
	displayArray(cards, arraySize);
	cout<<"-------------------------"<<endl;
	
	//sort the array....
	cardSort(cards, arraySize);
	
	cout<<"-------------------------"<<endl;
	cout<<"Final sorted array: ";
	displayArray(cards, arraySize);
	
	return 0;
}










